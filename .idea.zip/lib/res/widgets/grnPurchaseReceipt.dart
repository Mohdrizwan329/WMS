// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/Pages/putaway.dart';

import 'package:stackerbee_app/res/widgets/search_card.dart';

class GRNPurchaseReceipt extends StatefulWidget {
  const GRNPurchaseReceipt({super.key});

  @override
  State<GRNPurchaseReceipt> createState() => _GRNPurchaseReceiptState();
}

class _GRNPurchaseReceiptState extends State<GRNPurchaseReceipt> {
  //TextStyle Function
  final fontSize = 10.00;

  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(0, 0, 0, 1),
    double fontSize = 10.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  int numberOfPages = 10;
  int currentPage = 1;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width * .4;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50),
        child: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 142,
                height: 32,
                child: Image(image: AssetImage('assets/images/logo1_sb.png')),
              ),
              Container(
                width: 66,
                height: 30,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(4)),
                child: TextButton(
                  child: Text(
                    "DKB GGN",
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                  onPressed: () {},
                ),
              )
            ],
          ),
          backgroundColor: Color(0xff391F84),
          automaticallyImplyLeading: false,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
          icon: IconButton(
            onPressed: () {},
            icon: Icon(Icons.menu, color: Color(0xff391F84)),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 40,
            height: 40,
            child: CircleAvatar(
              backgroundColor: Color.fromRGBO(236, 100, 42, 1),
              child: IconButton(
                onPressed: () {},
                icon: Icon(Icons.add, color: Colors.white),
              ),
            ),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 23,
            height: 25,
            child: SvgPicture.asset('assets/images/backarrow.svg'),
          ),
          label: '',
        ),
      ]),
      body: Stack(children: [
        Column(children: [
          Flexible(
              flex: 5,
              child: const SearchCard(heading: 'GRN', searchText: 'Scan')),
          Flexible(
            flex: 25,
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.99,
              height: MediaQuery.of(context).size.height * 0.6,
              child: Column(
                children: [
                  Card(
                    child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('Purchase Receipt Lines',
                                    fontSize: 12, color: Color(0xff391F84)),
                                SizedBox(
                                  height: fontSize,
                                ),
                                Row(
                                  children: [
                                    commonText('Doc No. : ',
                                        color: Color(0xff391F84)),
                                    commonText('GRN-PP/22-23/100688',
                                        color: Colors.grey.shade700)
                                  ],
                                ),
                                SizedBox(
                                  height: fontSize,
                                ),
                                Row(
                                  children: [
                                    commonText('Vendor : ',
                                        color: Color(0xff391F84)),
                                    commonText('A & M Printer',
                                        color: Colors.grey.shade700)
                                  ],
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    commonText('No. of lines - ',
                                        color: Color(0xff391F84)),
                                    commonText('2', color: Colors.grey.shade700)
                                  ],
                                ),
                                SizedBox(
                                  height: fontSize,
                                ),
                                Row(
                                  children: [
                                    commonText('PO No. : ',
                                        color: Color(0xff391F84)),
                                    commonText('PO-PP/22-23/10635',
                                        color: Colors.grey.shade700)
                                  ],
                                ),
                                SizedBox(
                                  height: fontSize,
                                ),
                                Row(
                                  children: [
                                    commonText('Recd Qty/Qty : ',
                                        color: Color(0xff391F84)),
                                    commonText('0/10',
                                        color: Colors.grey.shade700)
                                  ],
                                )
                              ],
                            ),
                          ],
                        )),
                  ),
                  Card(
                    child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('I-PP100821',
                                    fontSize: 12, color: Color(0xff391F84)),
                                SizedBox(
                                  height: fontSize / 4,
                                ),
                                commonText('Item Name',
                                    color: Colors.grey.shade700),
                                SizedBox(height: 4),
                                Row(
                                  children: [
                                    commonText(
                                      'Lot No. : ',
                                      color: Color(0xff391F84),
                                    ),
                                    InkWell(
                                      child: commonText('stackerbee',
                                          color: Colors.grey.shade700),
                                      onTap: () {
                                        //Show Dialog
                                        showDialog(
                                            context: context,
                                            builder: (context) {
                                              return PopDialog(
                                                hintTitle: 'Enter Lot No.',
                                                title: 'Lot No.',
                                                text: '',
                                              );
                                            });
                                      },
                                    )
                                  ],
                                ),
                                SizedBox(height: 4),
                                Row(
                                  children: [
                                    commonText(
                                      'Serial No. : ',
                                      color: Color(0xff391F84),
                                    ),
                                    InkWell(
                                      child: commonText('001',
                                          color: Colors.grey.shade700),
                                      onTap: () {
                                        //Show Dialog
                                        showDialog(
                                            context: context,
                                            builder: (context) {
                                              return PopDialog(
                                                hintTitle: 'Enter Serial No.',
                                                title: 'Serial No.',
                                                text: '',
                                              );
                                            });
                                      },
                                    )
                                  ],
                                ),
                                SizedBox(height: 4),
                                Row(
                                  children: [
                                    commonText(
                                      'Exp : ',
                                      color: Color(0xff391F84),
                                    ),
                                    InkWell(
                                      child: commonText('08-12-2022',
                                          color: Colors.grey.shade700),
                                      onTap: () {
                                        //Show Dialog
                                        showDialog(
                                            context: context,
                                            builder: (context) {
                                              return PopDateDialog(
                                                hintDate: '08-12-2022',
                                                title: 'Exp Date',
                                              );
                                            });
                                      },
                                    ),
                                    SizedBox(
                                      width: fontSize,
                                    ),
                                    commonText(
                                      'Mfg : ',
                                      color: Color(0xff391F84),
                                    ),
                                    InkWell(
                                      child: commonText('08-12-2022',
                                          color: Colors.grey.shade700),
                                      onTap: () {
                                        //Show Dialog
                                        showDialog(
                                            context: context,
                                            builder: (context) {
                                              return PopDateDialog(
                                                hintDate: '08-12-2022',
                                                title: 'Mfg Date',
                                              );
                                            });
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                                height: fontSize * 6,
                                width: fontSize * 7,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xff814D4D),
                                    border: Border.all(
                                      color: Color(0xff814D4D),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Item \n Image',
                                      style: TextStyle(color: Colors.white),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                )),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      width: 35,
                                      height: 30,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(6),
                                          border: Border.all(
                                            color: const Color.fromRGBO(
                                                236, 100, 42, 1),
                                            width: 1,
                                          )),
                                      child: Text(
                                        '0',
                                        style: TextStyle(
                                          color: const Color.fromRGBO(
                                              236, 100, 42, 1),
                                          fontSize: fontSize * 2,
                                        ),
                                      ),
                                    ),
                                    commonText(' /10', fontSize: fontSize * 2),
                                  ],
                                ),
                                commonText('PCS',
                                    color: Colors.grey.shade700,
                                    fontSize: fontSize * 3 / 2),
                              ],
                            ),
                          ],
                        )),
                  ),
                ],
              ),
            ),
          ),
          //Page Number Generation
          Flexible(
            flex: 5,
            child: Container(
              height: 40,
              width: 300,
              decoration:
                  BoxDecoration(color: Color.fromARGB(193, 221, 221, 226)),
              child: NumberPaginator(
                numberPages: numberOfPages,
                onPageChange: (index) {
                  StepState() {
                    currentPage = index;
                  }
                },
                initialPage: currentPage,
                config: NumberPaginatorUIConfig(
                  buttonSelectedForegroundColor: Colors.white,
                  buttonSelectedBackgroundColor: Color(0xff391F84),
                  buttonUnselectedForegroundColor: Color(0xff391F84),
                  mode: ContentDisplayMode.numbers,
                  mainAxisAlignment: MainAxisAlignment.center,
                  contentPadding: EdgeInsets.only(left: 2, right: 2),
                  buttonShape: ContinuousRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ),
        ]),
        Positioned(
          bottom: 5,
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: 40,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  width: width,
                  height: 38,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xffDBDBDB)),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        "Cancel",
                        style: TextStyle(color: Color(0xff636363)),
                      )),
                ),
                SizedBox(
                  width: width,
                  height: 38,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xff391F84)),
                      onPressed: () {
                        //PopUp Dialog for Confirmation;
                        showDialog(
                            context: context,
                            builder: (context) {
                              return GRNSubmitDetailsPopup();
                            });
                      },
                      child: Text(
                        "Submit",
                        style: TextStyle(
                            color: Color.fromARGB(255, 234, 232, 232)),
                      )),
                )
              ],
            ),
          ),
        ),
      ]),
    );
  }
}


//PopUp Dialog
class PopDialog extends StatelessWidget {
  final String title;
  final String hintTitle;
  final String text;

  const PopDialog(
      {Key? key,
        required this.title,
        required this.hintTitle,
        required this.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: SizedBox(
        height: 180,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 34, left: 25, right: 25, bottom: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff391F84)),
                  ),
                  Row(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        width: 30,
                        height: 25,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: const Color.fromRGBO(236, 100, 42, 1),
                              width: 1,
                            )),
                        child: Text(
                          '0',
                          style: TextStyle(
                            color: const Color.fromRGBO(236, 100, 42, 1),
                            fontSize: 20,
                          ),
                        ),
                      ),
                      Text(
                        ' /10',
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 12, right: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                    colors: const [Colors.white, Color(0xff391F84)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter),
              ),
              child: Container(
                height: 35,
                margin: EdgeInsets.only(bottom: 2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                ),
                child: TextFormField(
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(10),
                      hintText: hintTitle,
                      border:
                      UnderlineInputBorder(borderSide: BorderSide.none)),
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(right: 26.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SizedBox(
                    width: 77,
                    height: 25,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xffD9D9D9)),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Cancel",
                          style: TextStyle(color: Color(0xff636363)),
                        )),
                  ),
                  SizedBox(width: 10),
                  SizedBox(
                    width: 77,
                    height: 25,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xffEC642A)),
                        onPressed: () {},
                        child: Text(
                          "Save",
                          style: TextStyle(color: Colors.white),
                        )),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

//PopUp of Date Mfg, Exp,
class PopDateDialog extends StatelessWidget {
  final String title;
  final String hintDate;

  const PopDateDialog({Key? key, required this.title, required this.hintDate})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Stack(children: [
        SizedBox(
          width: 360,
          height: 180,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 34, left: 25, right: 25, bottom: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Color(0xff391F84)),
                    ),
                    Row(
                      children: [
                        Container(
                          alignment: Alignment.center,
                          width: 30,
                          height: 25,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: const Color.fromRGBO(236, 100, 42, 1),
                                width: 1,
                              )),
                          child: Text(
                            '0',
                            style: TextStyle(
                              color: const Color.fromRGBO(236, 100, 42, 1),
                              fontSize: 20,
                            ),
                          ),
                        ),
                        Text(
                          ' /10',
                          style: TextStyle(fontSize: 20),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8),
              Container(
                margin: EdgeInsets.only(left: 12, right: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: LinearGradient(
                      colors: const [Colors.white, Color(0xff391F84)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter),
                ),
                child: Container(
                  height: 35,
                  margin: EdgeInsets.only(bottom: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.white,
                  ),
                  child: TextFormField(
                    decoration: InputDecoration(
                        suffixIcon: IconButton(
                          icon: Icon(Icons.calendar_month_outlined),
                          onPressed: () async {
                            // DateTime? datePicker = await showDatePicker(
                            //     context: context,
                            //     initialDate: DateTime.now(),
                            //     firstDate: DateTime(2021),
                            //     lastDate: DateTime(2023));

                            // if (datePicker != null) {
                            //   print(
                            //       'Date Selected: ${datePicker.day}-${datePicker.month}-${datePicker.year}');
                            // }
                          },
                        ),
                        contentPadding: EdgeInsets.only(left: 10, top: 2),
                        hintText: hintDate,
                        border:
                        UnderlineInputBorder(borderSide: BorderSide.none)),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.only(right: 26.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(
                      width: 77,
                      height: 25,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xffD9D9D9)),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            "Cancel",
                            style: TextStyle(color: Color(0xff636363)),
                          )),
                    ),
                    SizedBox(width: 10),
                    SizedBox(
                      width: 77,
                      height: 25,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xffEC642A)),
                          onPressed: () {},
                          child: Text(
                            "Save",
                            style: TextStyle(color: Colors.white),
                          )),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
        // Positioned(
        //     left: 20,
        //     top: 64,
        //     child: SizedBox(
        //       width: 273,
        //       child: Card(
        //         elevation: 0,
        //         shape: RoundedRectangleBorder(
        //             side: BorderSide(width: 260),
        //             borderRadius: BorderRadius.circular(10)),
        //         child: TextFormField(
        //           decoration: InputDecoration(
        //               suffixIcon: IconButton(
        //                 icon: Icon(Icons.calendar_month_outlined),
        //                 onPressed: () async {
        //                   // DateTime? datePicker = await showDatePicker(
        //                   //     context: context,
        //                   //     initialDate: DateTime.now(),
        //                   //     firstDate: DateTime(2021),
        //                   //     lastDate: DateTime(2023));
        //
        //                   // if (datePicker != null) {
        //                   //   print(
        //                   //       'Date Selected: ${datePicker.day}-${datePicker.month}-${datePicker.year}');
        //                   // }
        //                 },
        //               ),
        //               contentPadding: EdgeInsets.only(left: 10, top: 20),
        //               hintText: hintDate,
        //               border:
        //                   UnderlineInputBorder(borderSide: BorderSide.none)),
        //         ),
        //       ),
        //     ))
      ]),
    );
  }
}

//Submit Details PopUp Btn.
class GRNSubmitDetailsPopup extends StatelessWidget {
  const GRNSubmitDetailsPopup({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            SizedBox(
              width: 320,
              height: 200,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Submit Details",
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff391F84)),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Are you sure you want to submit \n these details",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                        color: Color(0xff585858)),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 77,
                        height: 25,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xffD9D9D9)),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              "No",
                              style: TextStyle(color: Color(0xff636363)),
                            )),
                      ),
                      SizedBox(width: 15),
                      SizedBox(
                        width: 77,
                        height: 25,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xffEC642A)),
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => PutAwayPage()));
                            },
                            child: Text(
                              "Yes",
                              style: TextStyle(color: Colors.white),
                            )),
                      )
                    ],
                  )
                ],
              ),
            ),
            Positioned(
                top: -35,
                child: SizedBox(
                  width: 70,
                  height: 70,
                  child: Card(
                    elevation: 2,
                    shape: CircleBorder(),
                    child: Icon(
                      Icons.question_mark,
                      size: 40,
                      color: Color(0xffEC642A),
                    ),
                  ),
                ))
          ]),
    );
  }
}
