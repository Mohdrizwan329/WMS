import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/Pages/transfer_order_list.dart';

import '../widgets/search_card.dart';

class CreateAssembly extends StatelessWidget {
  final fontSize = 12.00;

  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(57, 31, 132, 1),
    double fontSize = 12.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  Widget commonTextBox({
    String text = '',
    String prefillText = '',
    Color color = const Color.fromRGBO(57, 31, 132, 1),
    double fontSize = 12.00,
  }) {
    return SizedBox(
      height: fontSize * 2,
      width: fontSize * 8,
      child: TextField(
        controller: TextEditingController(text: prefillText),
        decoration: InputDecoration(
            // border: const OutlineInputBorder(),
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey.shade700)),
            hintText: text,
            hintStyle: TextStyle(
              fontSize: fontSize / 1.2,
              height: 0.7,
            )),
      ),
    );
  }

  const CreateAssembly({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int numberofPages;
    int currentPage;

    final width = MediaQuery.sizeOf(context).width * .4;
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: AppBar(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(
                  width: 142,
                  height: 32,
                  child: Image(image: AssetImage('assets/images/logo1_sb.png')),
                ),
                Container(
                  width: 66,
                  height: 30,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(4)),
                  child: TextButton(
                    child: const Text(
                      "DKB GGN",
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {},
                  ),
                )
              ],
            ),
            backgroundColor: const Color(0xff391F84),
            automaticallyImplyLeading: false,
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(
            icon: IconButton(
              onPressed: () {},
              icon: const Icon(Icons.menu, color: Color(0xff391F84)),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 40,
              height: 40,
              child: CircleAvatar(
                backgroundColor: const Color.fromRGBO(236, 100, 42, 1),
                child: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.add, color: Colors.white),
                ),
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 23,
              height: 25,
              child: SvgPicture.asset('assets/images/backarrow.svg'),
            ),
            label: '',
          ),
        ]),
        body: SingleChildScrollView(
          child: SizedBox(
            child: Column(
              children: [
                const SearchCard(
                  heading: 'Assembly Order',
                  searchText: 'Search',
                  sizeFactor: 2.4,
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  commonText('No. * ', fontSize: 13),
                                  SizedBox(
                                    height: fontSize,
                                  ),
                                  commonText('No. of Qty * ', fontSize: 13)
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  commonText('Asmbly-PP/21/100445',
                                      color: Colors.grey.shade700,
                                      fontSize: 10),
                                  SizedBox(
                                    height: fontSize,
                                  ),
                                  commonTextBox(text: '10'),
                                ],
                              ),
                              Column(
                                children: [
                                  commonText('Item No. * ', fontSize: 13),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  commonTextBox(text: 'Select Item No.'),
                                ],
                              ),
                              SizedBox(
                                height: fontSize,
                              ),
                            ],
                          ),
                        ],
                      )),
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  commonText('Assembly Quantity : '),
                                  commonText('0', color: Colors.grey.shade700)
                                ],
                              ),
                              SizedBox(
                                height: fontSize,
                              ),
                              Row(
                                children: [
                                  commonText('Remaining Quantity : '),
                                  commonText('10', color: Colors.grey.shade700)
                                ],
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  commonText('Qty to Assemble '),
                                  commonText('10',
                                      color:
                                          const Color.fromRGBO(236, 100, 42, 1),
                                      fontSize: 14),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            width: fontSize / 10,
                          ),
                        ],
                      )),
                ),
                InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const TransferOrderList()));
                  },
                  child: Card(
                    child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('I-PP100821', fontSize: 12),
                                SizedBox(
                                  height: fontSize / 4,
                                ),
                                commonText('Description : ',
                                    color: Colors.grey.shade700),
                                SizedBox(
                                  height: fontSize / 1.5,
                                ),
                                commonText(
                                  'Qty per BOM : ',
                                ),
                                SizedBox(
                                  height: fontSize * 1 / 1.5,
                                ),
                                Row(
                                  children: [
                                    commonText(
                                      'Consumed / Remaining Qty : ',
                                    ),
                                    commonText('7 / 3',
                                        color: Colors.grey.shade700)
                                  ],
                                ),
                                SizedBox(
                                  height: fontSize * 1 / 2,
                                ),
                                Row(
                                  children: [
                                    commonText(
                                      'Qty to Consume : ',
                                    ),
                                    commonText('10', color: Colors.grey.shade700),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: fontSize * 5,
                              width: fontSize,
                            ),
                            SizedBox(
                                height: fontSize * 6,
                                width: fontSize * 7,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xff814D4D),
                                    border: Border.all(
                                      color: const Color(0xff814D4D),
                                    ),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      'Item \n Image',
                                      style: TextStyle(color: Colors.white),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                )),
                            SizedBox(
                              height: fontSize / 2,
                            )
                          ],
                        )),
                  ),
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('I-PP100821', fontSize: 12),
                              SizedBox(
                                height: fontSize / 4,
                              ),
                              commonText('Description : ',
                                  color: Colors.grey.shade700),
                              SizedBox(
                                height: fontSize / 1.5,
                              ),
                              commonText(
                                'Qty per BOM : ',
                              ),
                              SizedBox(
                                height: fontSize * 1 / 1.5,
                              ),
                              Row(
                                children: [
                                  commonText(
                                    'Consumed / Remaining Qty : ',
                                  ),
                                  commonText('7 / 3',
                                      color: Colors.grey.shade700)
                                ],
                              ),
                              SizedBox(
                                height: fontSize * 1 / 2,
                              ),
                              Row(
                                children: [
                                  commonText(
                                    'Qty to Consume : ',
                                  ),
                                  commonText('10', color: Colors.grey.shade700),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: fontSize * 5,
                            width: fontSize,
                          ),
                          SizedBox(
                              height: fontSize * 6,
                              width: fontSize * 7,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xff814D4D),
                                  border: Border.all(
                                    color: const Color(0xff814D4D),
                                  ),
                                ),
                                child: const Center(
                                  child: Text(
                                    'Item \n Image',
                                    style: TextStyle(color: Colors.white),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              )),
                          SizedBox(
                            height: fontSize / 2,
                          )
                        ],
                      )),
                ),
                SizedBox(
                  height: MediaQuery.sizeOf(context).height * .18,
                ),
                SizedBox(
                  height: 40,
                  width: 300,
                  child: NumberPaginator(
                    numberPages: numberofPages = 10,
                    onPageChange: (index) {},
                    initialPage: currentPage = 0,
                    config: NumberPaginatorUIConfig(
                      buttonSelectedForegroundColor: Colors.white,
                      buttonSelectedBackgroundColor: const Color(0xff391F84),
                      buttonUnselectedForegroundColor: const Color(0xff391F84),
                      mode: ContentDisplayMode.numbers,
                      mainAxisAlignment: MainAxisAlignment.center,
                      contentPadding: const EdgeInsets.only(left: 2, right: 2),
                      buttonShape: ContinuousRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
