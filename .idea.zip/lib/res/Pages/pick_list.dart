// ignore_for_file: prefer_const_constructors, must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/Pages/pickup_details.dart';

import '../widgets/search_card.dart';

class PickList extends StatelessWidget {
  final fontSize = 10.00;

  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(0, 0, 0, 1),
    double fontSize = 10.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  int numberOfPages = 10;
  int currentPage = 1;

  PickList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(50),
          child: AppBar(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: 142,
                  height: 32,
                  child: Image(image: AssetImage('assets/images/logo1_sb.png')),
                ),
                Container(
                  width: 66,
                  height: 30,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(4)),
                  child: TextButton(
                    child: Text(
                      "DKB GGN",
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {},
                  ),
                )
              ],
            ),
            backgroundColor: Color(0xff391F84),
            automaticallyImplyLeading: false,
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(
            icon: IconButton(
              onPressed: () {},
              icon: Icon(Icons.menu, color: Color(0xff391F84)),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 40,
              height: 40,
              child: CircleAvatar(
                backgroundColor: Color.fromRGBO(236, 100, 42, 1),
                child: IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.add, color: Colors.white),
                ),
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 23,
              height: 25,
              child: SvgPicture.asset('assets/images/backarrow.svg'),
            ),
            label: '',
          ),
        ]),
        body: Column(
          children: [
            const SearchCard(
              heading: 'Pick',
              searchText: 'Scan',
            ),
            Card(
              child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          commonText('Doc No.'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Shipment No.'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Order No.'),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          commonText('Doc Date'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Created By'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Assigned to'),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          commonText('No. of Lines'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Recd Qty/Qty'),
                          SizedBox(
                            height: fontSize,
                          ),
                          commonText('Status'),
                        ],
                      )
                    ],
                  )),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.99,
              height: MediaQuery.of(context).size.height * 0.57,
              child: Column(children: [
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('Pick-PP/21-22/101037'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Ship-PP/21-22/100762'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('SO-PP/21-22/101016'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('2022-11-21'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Muskan'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Stackerbee',
                                  color: const Color.fromRGBO(57, 31, 132, 1)),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('0/15'),
                              SizedBox(
                                height: fontSize,
                              ),
                              InkWell(
                                child: Container(
                                    alignment: Alignment.center,
                                    height: fontSize * 2,
                                    padding: const EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(
                                          color: const Color(0xff0DC114),
                                          width: 1,
                                        )),
                                    child: commonText(
                                      'Released',
                                      color: const Color(0xff0DC114),
                                    )),
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => PickDetail()));
                                },
                              )
                            ],
                          )
                        ],
                      )),
                ),
              ]),
            ),
            //Page Number Generation
            Container(
              height: 40,
              width: 300,
              decoration:
                  BoxDecoration(color: Color.fromARGB(193, 221, 221, 226)),
              child: NumberPaginator(
                numberPages: numberOfPages,
                onPageChange: (index) {
                  StepState() {
                    currentPage = index;
                  }
                },
                initialPage: currentPage,
                config: NumberPaginatorUIConfig(
                  buttonSelectedForegroundColor: Colors.white,
                  buttonSelectedBackgroundColor: Color(0xff391F84),
                  buttonUnselectedForegroundColor: Color(0xff391F84),
                  mode: ContentDisplayMode.numbers,
                  mainAxisAlignment: MainAxisAlignment.center,
                  contentPadding: EdgeInsets.only(left: 2, right: 2),
                  buttonShape: ContinuousRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
