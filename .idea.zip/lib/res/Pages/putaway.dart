// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/widgets/putAwayPurchaseReceipt%20copy.dart';
import 'package:stackerbee_app/res/widgets/search_card.dart';

class PutAwayPage extends StatefulWidget {
  const PutAwayPage({super.key});

  @override
  State<PutAwayPage> createState() => _PutAwayPageState();
}

class _PutAwayPageState extends State<PutAwayPage> {
  final fontSize = 10.00;
  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(0, 0, 0, 1),
    double fontSize = 10.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  int numberOfPages = 10;
  int currentPage = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50),
        child: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 142,
                height: 32,
                child: Image(image: AssetImage('assets/images/logo1_sb.png')),
              ),
              Container(
                width: 66,
                height: 30,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(4)),
                child: TextButton(
                  child: Text(
                    "DKB GGN",
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                  onPressed: () {},
                ),
              )
            ],
          ),
          backgroundColor: Color(0xff391F84),
          automaticallyImplyLeading: false,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
          icon: IconButton(
            onPressed: () {},
            icon: Icon(Icons.menu, color: Color(0xff391F84)),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 40,
            height: 40,
            child: CircleAvatar(
              backgroundColor: Color.fromRGBO(236, 100, 42, 1),
              child: IconButton(
                onPressed: () {},
                icon: Icon(Icons.add, color: Colors.white),
              ),
            ),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 23,
            height: 25,
            child: SvgPicture.asset('assets/images/backarrow.svg'),
          ),
          label: '',
        ),
      ]),
      body: Column(
        children: [
          const SearchCard(heading: 'Put-away', searchText: 'Scan',),
          Card(
            child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('Doc No.'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('GRN No.'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('PO No.'),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('Doc Date'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Created By'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Assigned to'),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('No. of Lines'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Recd Qty/Qty'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Status'),
                      ],
                    )
                  ],
                )),
          ),
          //1st list
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.99,
            height: MediaQuery.of(context).size.height * 0.57,
            child: Column(
              children: [
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('Put-PP/22-23/100531'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('PGRN-PP/11/21/100428'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('PO-PP/22-23/10635'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('2022-11-21'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Muskan'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Stackerbee',
                                  color: Color(0xff391F84)),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText(
                                '0/15',
                              ),
                              SizedBox(
                                height: fontSize,
                              ),
                              InkWell(
                                child: Container(
                                  alignment: Alignment.center,
                                  height: fontSize * 2,
                                  width: fontSize * 5,
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      border: Border.all(
                                        color: const Color(0xff0DC114),
                                        width: 1,
                                      )),
                                  child: commonText(
                                    'Released',
                                    color: const Color(0xff0DC114),
                                  ),
                                ),
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              PutAwayPurchaseReceipt()));
                                },
                              )
                            ],
                          )
                        ],
                      )),
                ),
              ],
            ),
          ),
          //Page Number Generation
          Container(
            height: 40,
            width: 300,
            decoration:
                BoxDecoration(color: Color.fromARGB(193, 221, 221, 226)),
            child: NumberPaginator(
              numberPages: numberOfPages,
              onPageChange: (index) {
                StepState() {
                  currentPage = index;
                }
              },
              initialPage: currentPage,
              config: NumberPaginatorUIConfig(
                buttonSelectedForegroundColor: Colors.white,
                buttonSelectedBackgroundColor: Color(0xff391F84),
                buttonUnselectedForegroundColor: Color(0xff391F84),
                mode: ContentDisplayMode.numbers,
                mainAxisAlignment: MainAxisAlignment.center,
                contentPadding: EdgeInsets.only(left: 2, right: 2),
                buttonShape: ContinuousRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          )
        ],
      ),
    );
  }
}
