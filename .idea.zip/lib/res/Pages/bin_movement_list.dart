import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/Pages/bin_movement_detail.dart';

import '../widgets/search_card.dart';

class BinMovementList extends StatelessWidget {
  final fontSize = 10.00;

  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(0, 0, 0, 1),
    double fontSize = 12.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  const BinMovementList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int numberofPages;
    int currentPage;
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: AppBar(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(
                  width: 142,
                  height: 32,
                  child: Image(image: AssetImage('assets/images/logo1_sb.png')),
                ),
                Container(
                  width: 66,
                  height: 30,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(4)),
                  child: TextButton(
                    child: const Text(
                      "DKB GGN",
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {},
                  ),
                )
              ],
            ),
            backgroundColor: const Color(0xff391F84),
            automaticallyImplyLeading: false,
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(
            icon: IconButton(
              onPressed: () {},
              icon: const Icon(Icons.menu, color: Color(0xff391F84)),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 40,
              height: 40,
              child: CircleAvatar(
                backgroundColor: const Color.fromRGBO(236, 100, 42, 1),
                child: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.add, color: Colors.white),
                ),
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 23,
              height: 25,
              child: SvgPicture.asset('assets/images/backarrow.svg'),
            ),
            label: '',
          ),
        ]),
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .8,
            child: Column(
              children: [
                const SearchCard(
                  heading: 'Bin Movement',
                  searchText: 'Scan Bin',
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('Doc No.'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('User'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('Doc Date'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Created By'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('No. of Lines'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Status'),
                            ],
                          )
                        ],
                      )),
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('BB-PP/22-23/101180'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Muskan'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('2022-11-21'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('Stackerbee'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('2'),
                              SizedBox(
                                height: fontSize,
                              ),
                              Container(
                                alignment: Alignment.center,
                                height: fontSize * 2,
                                width: 70,
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(3),
                                    border: Border.all(
                                      color: const Color.fromRGBO(8, 155, 102, 1),
                                      width: 1,
                                    )),
                                child: InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const BinMovementDetail()));
                                    },
                                    child: commonText(
                                      'Posted',
                                      color: const Color.fromRGBO(8, 155, 102, 1),
                                    )),
                              )
                            ],
                          )
                        ],
                      )),
                ),
                SizedBox(
                  height: MediaQuery.sizeOf(context).height * .5,
                ),
                SizedBox(
                  height: 40,
                  width: 300,
                  child: NumberPaginator(
                    numberPages: numberofPages = 10,
                    onPageChange: (index) {},
                    initialPage: currentPage = 0,
                    config: NumberPaginatorUIConfig(
                      buttonSelectedForegroundColor: Colors.white,
                      buttonSelectedBackgroundColor: const Color(0xff391F84),
                      buttonUnselectedForegroundColor: const Color(0xff391F84),
                      mode: ContentDisplayMode.numbers,
                      mainAxisAlignment: MainAxisAlignment.center,
                      contentPadding: const EdgeInsets.only(left: 2, right: 2),
                      buttonShape: ContinuousRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
