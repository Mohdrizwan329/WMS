// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/widgets/grnPurchaseReceipt.dart';
import 'package:stackerbee_app/res/widgets/search_card.dart';

class GRNPage extends StatefulWidget {
  const GRNPage({super.key});

  @override
  State<GRNPage> createState() => _GRNPageState();
}

class _GRNPageState extends State<GRNPage> {
  final fontSize = 10.00;
  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(0, 0, 0, 1),
    double fontSize = 10.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  int numberOfPages = 10;
  int currentPage = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50),
        child: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 142,
                height: 32,
                child: Image(image: AssetImage('assets/images/logo1_sb.png')),
              ),
              Container(
                width: 66,
                height: 30,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(4)),
                child: TextButton(
                  child: Text(
                    "DKB GGN",
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                  onPressed: () {},
                ),
              )
            ],
          ),
          backgroundColor: Color(0xff391F84),
          automaticallyImplyLeading: false,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
          icon: IconButton(
            onPressed: () {},
            icon: Icon(Icons.menu, color: Color(0xff391F84)),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 40,
            height: 40,
            child: CircleAvatar(
              backgroundColor: Color.fromRGBO(236, 100, 42, 1),
              child: IconButton(
                onPressed: () {},
                icon: Icon(Icons.add, color: Colors.white),
              ),
            ),
          ),
          label: '',
        ),
        BottomNavigationBarItem(
          icon: SizedBox(
            width: 23,
            height: 25,
            child: SvgPicture.asset('assets/images/backarrow.svg'),
          ),
          label: '',
        ),
      ]),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SearchCard(heading: 'GRN', searchText: 'Scan'),
          Card(
            child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('Doc No.'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Doc Date'),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('PO No.'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Vendor'),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        commonText('No. of Lines'),
                        SizedBox(
                          height: fontSize,
                        ),
                        commonText('Recd Qty/Qty'),
                      ],
                    )
                  ],
                )),
          ),
          //1st list
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.99,
            height: MediaQuery.of(context).size.height * 0.6,
            child: Column(
              children: [
                InkWell(
                  child: Card(
                    child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('GRN-PP/22-23/100688'),
                                SizedBox(
                                  height: fontSize,
                                ),
                                commonText('2022-11-21'),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('PO-PP/22-23/10635'),
                                SizedBox(
                                  height: fontSize,
                                ),
                                commonText('A & M Printer'),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                commonText('5'),
                                SizedBox(
                                  height: fontSize,
                                ),
                                commonText(
                                  '0/15',
                                )
                              ],
                            )
                          ],
                        )),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => GRNPurchaseReceipt()));
                  },
                ),

                //2nd list
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('GRN-PP/22-23/100688'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('2022-11-21'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('PO-PP/22-23/10635'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('A & M Printer'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText(
                                '0/15',
                              )
                            ],
                          )
                        ],
                      )),
                ),
                //3rd list
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('GRN-PP/22-23/100688'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('2022-11-21'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('PO-PP/22-23/10635'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('A & M Printer'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText(
                                '0/15',
                              )
                            ],
                          )
                        ],
                      )),
                ),
                //4th list
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('GRN-PP/22-23/100688'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('2022-11-21'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('PO-PP/22-23/10635'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('A & M Printer'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText(
                                '0/15',
                              )
                            ],
                          )
                        ],
                      )),
                ),
                //5th list
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('GRN-PP/22-23/100688'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('2022-11-21'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('PO-PP/22-23/10635'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText('A & M Printer'),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              commonText('5'),
                              SizedBox(
                                height: fontSize,
                              ),
                              commonText(
                                '0/15',
                              )
                            ],
                          )
                        ],
                      )),
                ),
              ],
            ),
          ),
          //Page Number Generation
          Container(
            height: 40,
            width: 300,
            decoration:
                BoxDecoration(color: Color.fromARGB(193, 221, 221, 226)),
            child: NumberPaginator(
              numberPages: numberOfPages,
              onPageChange: (index) {
                StepState() {
                  currentPage = index;
                }
              },
              initialPage: currentPage,
              config: NumberPaginatorUIConfig(
                buttonSelectedForegroundColor: Colors.white,
                buttonSelectedBackgroundColor: Color(0xff391F84),
                buttonUnselectedForegroundColor: Color(0xff391F84),
                mode: ContentDisplayMode.numbers,
                mainAxisAlignment: MainAxisAlignment.center,
                contentPadding: EdgeInsets.only(left: 2, right: 2),
                buttonShape: ContinuousRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          )
        ],
      ),
    );
  }
}
