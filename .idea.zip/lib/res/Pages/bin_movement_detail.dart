import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:number_paginator/number_paginator.dart';
import 'package:stackerbee_app/res/Pages/assembly_order_list.dart';

import '../widgets/search_card.dart';

class BinMovementDetail extends StatelessWidget {
  final fontSize = 12.00;

  Widget commonText(
    String text, {
    Color color = const Color.fromRGBO(57, 31, 132, 1),
    double fontSize = 12.00,
  }) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  Widget commonTextBox({
    String text = '',
    String prefillText = '',
    Color color = const Color.fromRGBO(57, 31, 132, 1),
    double fontSize = 12.00,
  }) {
    return SizedBox(
      height: fontSize * 2,
      width: fontSize * 8,
      child: TextField(
        controller: TextEditingController(text: prefillText),
        decoration: InputDecoration(
            // border: const OutlineInputBorder(),
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey.shade700)),
            hintText: text,
            hintStyle: TextStyle(fontSize: fontSize, height: 0.1)),
      ),
    );
  }

  const BinMovementDetail({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var currentPage = 0;
    var numberofPages = 10;

    final width = MediaQuery.sizeOf(context).width * .4;
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: AppBar(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(
                  width: 142,
                  height: 32,
                  child: Image(image: AssetImage('assets/images/logo1_sb.png')),
                ),
                Container(
                  width: 66,
                  height: 30,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(4)),
                  child: TextButton(
                    child: const Text(
                      "DKB GGN",
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {},
                  ),
                )
              ],
            ),
            backgroundColor: const Color(0xff391F84),
            automaticallyImplyLeading: false,
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(
            icon: IconButton(
              onPressed: () {},
              icon: const Icon(Icons.menu, color: Color(0xff391F84)),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 40,
              height: 40,
              child: CircleAvatar(
                backgroundColor: const Color.fromRGBO(236, 100, 42, 1),
                child: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.add, color: Colors.white),
                ),
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              width: 23,
              height: 25,
              child: SvgPicture.asset('assets/images/backarrow.svg'),
            ),
            label: '',
          ),
        ]),
        body: SingleChildScrollView(
          child: SizedBox(
            child: Column(
              children: [
                const SearchCard(
                  heading: 'Bin Movement',
                  searchText: 'Search',
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          commonText('Move Order Lines', fontSize: 16),
                          SizedBox(
                            height: fontSize,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                children: [
                                  commonText('Doc No.', fontSize: 14),
                                  SizedBox(
                                    height: fontSize,
                                  ),
                                  commonText('Remarks', fontSize: 14)
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  commonText('BB-PP/22-23/100180',
                                      color: Colors.grey.shade700),
                                  SizedBox(
                                    height: fontSize,
                                  ),
                                  commonTextBox(),
                                ],
                              ),
                              Column(
                                children: [
                                  commonText('No. of lines -', fontSize: 14),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  commonText('2', color: Colors.grey.shade700)
                                ],
                              ),
                              SizedBox(
                                height: fontSize,
                              ),
                            ],
                          ),
                        ],
                      )),
                ),
                Card(
                  child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      commonText('I-PP100821', fontSize: 14),
                                      SizedBox(
                                        height: fontSize / 4,
                                      ),
                                      commonText('Item Name',
                                          color: Colors.grey.shade700),
                                      SizedBox(
                                        height: fontSize,
                                      ),
                                      Row(
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              //Show Dialog
                                              showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return const PopDialog(
                                                      hintTitle: 'Enter Lot No.',
                                                      title: 'Lot No.',
                                                      text: '',
                                                    );
                                                  });
                                            },
                                            child: Row(
                                              children: [
                                                commonText(
                                                  'Lot No. : ',
                                                ),
                                                commonText('stackerbee',
                                                    color: Colors.grey.shade700),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: fontSize,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              //Show Dialog
                                              showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return const PopDialog(
                                                      hintTitle: 'Enter Serial No.',
                                                      title: 'Serial No.',
                                                      text: '',
                                                    );
                                                  });
                                            },
                                            child: Row(
                                              children: [
                                                commonText(
                                                  'Serial No. : ',
                                                ),
                                                commonText('001',
                                                    color: Colors.grey.shade700),
                                              ],
                                            ),
                                          ),

                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    width: fontSize * 2,
                                  ),
                                  Column(
                                    children: [
                                      SizedBox(
                                          height: fontSize * 5,
                                          width: fontSize * 5,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: const Color(0xff814D4D),
                                              border: Border.all(
                                                color: const Color(0xff814D4D),
                                              ),
                                            ),
                                            child: const Center(
                                              child: Text(
                                                'Item \n Image',
                                                style: TextStyle(color: Colors.white),
                                                textAlign: TextAlign.center,
                                              ),
                                            ),
                                          )),
                                    ],
                                  )
                                ],
                              ),
                              SizedBox(
                                height: fontSize * 1 / 2,
                              ),
                              InkWell(
                                onTap: () {
                                  //Show Dialog
                                  showDialog(
                                      context: context,
                                      builder: (context) {
                                        return const PopDialog(
                                          hintTitle: 'Enter Bin Code',
                                          title: 'From Bin',
                                          text: '',
                                        );
                                      });
                                },
                                child: Row(
                                  children: [
                                    commonText(
                                      'Form Bin : ',
                                    ),
                                    commonText('testbin', color: Colors.grey.shade700)
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: fontSize * 1 / 2,
                              ),
                              InkWell(
                                onTap: () {
                                  //Show Dialog
                                  showDialog(
                                      context: context,
                                      builder: (context) {
                                        return const PopDialog(
                                          hintTitle: 'Enter Bin Code',
                                          title: 'To Bin',
                                          text: '',
                                        );
                                      });
                                },
                                child: Row(
                                  children: [
                                    commonText(
                                      'To Bin : ',
                                    ),
                                    commonText('testbin',
                                        color: Colors.grey.shade700),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: fontSize * 2,
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              commonText('10', fontSize: fontSize * 3 / 2),
                              Text(
                                '0',
                                style: TextStyle(
                                  color: const Color.fromRGBO(236, 100, 42, 1),
                                  fontSize: fontSize * 3 / 2,
                                ),
                              ),
                              commonText('PCS',
                                  color: Colors.grey.shade700, fontSize: fontSize),
                            ],
                          ),
                        ],
                      )),
                ),
                SizedBox(
                  height: MediaQuery.sizeOf(context).height * .28,
                ),
                SizedBox(
                  height: 40,
                  width: 300,
                  child: NumberPaginator(
                    numberPages: numberofPages = 10,
                    onPageChange: (index) {},
                    initialPage: currentPage = 0,
                    config: NumberPaginatorUIConfig(
                      buttonSelectedForegroundColor: Colors.white,
                      buttonSelectedBackgroundColor: const Color(0xff391F84),
                      buttonUnselectedForegroundColor: const Color(0xff391F84),
                      mode: ContentDisplayMode.numbers,
                      mainAxisAlignment: MainAxisAlignment.center,
                      contentPadding: const EdgeInsets.only(left: 2, right: 2),
                      buttonShape: ContinuousRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: 40,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        width: width,
                        height: 38,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xffDBDBDB)),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text(
                              "Cancel",
                              style: TextStyle(color: Color(0xff636363)),
                            )),
                      ),
                      SizedBox(
                        width: width,
                        height: 38,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xff391F84)),
                            onPressed: () {
                              //PopUp Dialog for Confirmation;
                              showDialog(
                                  context: context,
                                  builder: (context) {
                                    return const BoxSubmitDetailsPopup();
                                  });
                            },
                            child: const Text(
                              "Submit",
                              style: TextStyle(
                                  color: Color.fromARGB(255, 234, 232, 232)),
                            )),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


//PopUp Dialog
class PopDialog extends StatelessWidget {
  final String title;
  final String hintTitle;
  final String text;

  const PopDialog(
      {Key? key,
        required this.title,
        required this.hintTitle,
        required this.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: SizedBox(
        height: 180,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 34, left: 25, right: 25, bottom: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff391F84)),
                  ),
                  Row(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        width: 30,
                        height: 25,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: const Color.fromRGBO(236, 100, 42, 1),
                              width: 1,
                            )),
                        child: Text(
                          '0',
                          style: TextStyle(
                            color: const Color.fromRGBO(236, 100, 42, 1),
                            fontSize: 20,
                          ),
                        ),
                      ),
                      Text(
                        ' /10',
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 12, right: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                    colors: const [Colors.white, Color(0xff391F84)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter),
              ),
              child: Container(
                height: 35,
                margin: EdgeInsets.only(bottom: 2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                ),
                child: TextFormField(
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(10),
                      hintText: hintTitle,
                      border:
                      UnderlineInputBorder(borderSide: BorderSide.none)),
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(right: 26.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SizedBox(
                    width: 77,
                    height: 25,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xffD9D9D9)),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Cancel",
                          style: TextStyle(color: Color(0xff636363)),
                        )),
                  ),
                  SizedBox(width: 10),
                  SizedBox(
                    width: 77,
                    height: 25,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xffEC642A)),
                        onPressed: () {},
                        child: Text(
                          "Save",
                          style: TextStyle(color: Colors.white),
                        )),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}


//Popup Submit  Btn
class BoxSubmitDetailsPopup extends StatelessWidget {
  const BoxSubmitDetailsPopup({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            SizedBox(
              width: 320,
              height: 200,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Submit Details",
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff391F84)),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Are you sure you want to submit \n these details",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                        color: Color(0xff585858)),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 77,
                        height: 25,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xffD9D9D9)),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text(
                              "No",
                              style: TextStyle(color: Color(0xff636363)),
                            )),
                      ),
                      const SizedBox(width: 15),
                      SizedBox(
                        width: 77,
                        height: 25,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xffEC642A)),
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const AssemblyOrderList()));
                            },
                            child: const Text(
                              "Yes",
                              style: TextStyle(color: Colors.white),
                            )),
                      )
                    ],
                  )
                ],
              ),
            ),
            const Positioned(
                top: -35,
                child: SizedBox(
                  width: 70,
                  height: 70,
                  child: Card(
                    elevation: 2,
                    shape: CircleBorder(),
                    child: Icon(
                      Icons.question_mark,
                      size: 40,
                      color: Color(0xffEC642A),
                    ),
                  ),
                ))
          ]),
    );
  }
}
