// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:stackerbee_app/login_btn.dart';
import 'package:stackerbee_app/res/Pages/assembly_detail.dart';
import 'package:stackerbee_app/res/Pages/bin_movement_detail.dart';
import 'package:stackerbee_app/res/Pages/box_packing_detail.dart';
import 'package:stackerbee_app/res/Pages/create_assembly.dart';
import 'package:stackerbee_app/res/Pages/create_transfer.dart';
import 'package:stackerbee_app/res/Pages/mainfest_detail.dart';
import 'package:stackerbee_app/res/Pages/pickup_details.dart';
import 'package:stackerbee_app/res/widgets/grnPurchaseReceipt.dart';
import 'package:stackerbee_app/res/widgets/putAwayPurchaseReceipt%20copy.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.amber,
      ),
      home: LoginPage(),
    );
  }
}
